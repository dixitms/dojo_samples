/**
 * 
 */

define([ 'dojo/on', 'dojo/dom', 'dojo/query', 'dojo/_base/declare',
		'dojo/Evented', 'dojo/aspect', 'dojo/topic' ],

function(on, dom, query, declare, Evented, aspect, topic) {

	// -------------------------------------------------------

	var actionButton = dom.byId('actionButton');

	// add event listener directly to DOM node
	on(actionButton, 'click', function() {
		console.log('button clicked...');
	});

	// use event delegation to listen for events
	on(document, '.myClass:click', function(e) {
		console.log('doc : button clicked...');
	});

	// -------------------------------------------------------

	var MyClass = declare([ Evented ], {

		run : function() {
			this.emit('custom-event', {
				name : 'world'
			});
		}

	});

	var c = new MyClass();

	on(c, 'custom-event', function(data) {
		console.log('hello-' + data.name);
	});

	c.run();

	// -----------------------------------------------------------

	var rand = {
		getNumber : function(min, max) {
			return Math.floor(Math.random() * (max - min + 1)) + min;
		}
	};

	// aspect.after(rand, 'getNumber', function(value) {
	// console.log('actual result :' + value);
	// return 4;
	// });

	// aspect.before(rand, 'getNumber', function(min, max) {
	// console.log('original arguments: ' + min + ', ' + max);
	// return [ 6, 16 ];
	// });

	aspect.around(rand, 'getNumber', function(origMethod) {
		return function(min, max) {
			if (min === max) {
				console.log('not calling original method');
				return min;
			}
			// only call the original method if min !== max
			return origMethod(min, max);
		}
	});

	console.log('returned result :' + rand.getNumber(10, 10));

	// ---------------------------------------------------------------------

	on(dom.byId('pubButton'), 'click', function(e) {
		var data = {
			name : "Naga"
		};
		topic.publish('topicA', data);
	});

	topic.subscribe('topicA', function(data) {
		console.log('Hello ' + data.naga);
	});

	topic.subscribe('topicA', function(data) {
		console.log('Hi ' + data.name);
	});
	
	//--------------------------------------------------------------------------

});