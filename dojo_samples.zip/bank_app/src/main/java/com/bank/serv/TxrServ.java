package com.bank.serv;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.bank.service.TransferService;

public class TxrServ extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		String amount = req.getParameter("amount");
		String from = req.getParameter("from");
		String to = req.getParameter("to");

		ServletContext servletContext = getServletContext();

		ApplicationContext context = WebApplicationContextUtils
				.getRequiredWebApplicationContext(servletContext);

		TransferService transferService = context.getBean("txrServ",
				TransferService.class);

		transferService.tranfser(Double.parseDouble(amount), from, to);

		resp.sendRedirect("index.html");

	}

}
