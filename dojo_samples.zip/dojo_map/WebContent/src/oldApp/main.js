/**
 * 
 */


define([ 'dojo/main' ], function(dojo) {
	console.log(dojo.version);
});