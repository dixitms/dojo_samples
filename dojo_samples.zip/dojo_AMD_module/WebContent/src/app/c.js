/**
 * 
 */

define(function() {

	return function() {
		console.log('u called me ....');
	}

});