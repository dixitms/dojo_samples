/**
 * 
 */

/*
 * 
 * basic concepts
 * 
 * 1. object === hash 2. JS is functional programming
 * 
 * functins are first-class citizens.
 * 
 * 3. JS does not define any OO notations.
 * 
 * classes/inheritance
 * 
 */

// object === hash
// var obj1 = {};
// var obj2 = new Object();
//
// console.log(typeof obj1);
// console.log(obj1 instanceof Object);
// console.log(obj2 instanceof Object);
// console.log(obj1.constructor);
//
// var obj = {};
// obj.name = "Java Script";
//
// console.log(obj['name']);
//
// -----------------------------------------------------
// object prototype chains
// var vehicle = {
// powered : true
// }
// var volvo = {
// seats : 4
// }
// console.log(vehicle.powered);
// console.log(volvo.seats);
// console.log(volvo.powered);
// volvo.__proto__ = vehicle; // parent
// console.log(volvo.powered);
//
// volvo.powered = 'gasoline';
// console.log(volvo.powered);
// console.log(vehicle.powered);
// console.log(volvo.__proto__.powered);
// -----------------------------------------------------
// Defining Function
// function add(a, b) {
// return a + b;
// }
//
// var negate = function(a) {
// return -a;
// }
//
// console.log(add(12, 12));
// console.log(add.apply(null, [ 12, 12 ]));
// console.log(add.call(null, 12, 12));
//
// var abcObj = {
// abc : function(a, b) {
// console.log(this.foo + " --> called abc with " + a + ' ' + b);
// }
// };
//
// abcObj.abc(1, 2);
//
// var fooObj = {
// foo : 'Foo'
// }
//
// abcObj.abc.apply(fooObj, [ 1, 2 ]);
// abcObj.abc.call(fooObj, 12, 12);
// console.log(add.name);
// console.log(negate.name);
//
// console.log(add.length);
//
// console.log(typeof add.apply);
// console.log(negate.constructor);
//
// var negate2=new Function('a','return -a');
// console.log(negate2(12));
// -----------------------------------------------------
// JS closure
//
// function greetor(msg) {
// var counter = 0;
// var prefix = '.' + msg + ' ';
// return function(name) {
// counter++;
// return counter + prefix + name + '!'
// }
// }
//
// var greet = greetor('hello');
// console.log(greet('a'));
// console.log(greet('b'));
// console.log(greet('c'));
// -----------------------------------------------------
// creating class
/*
 * imp note : there is no standard 'class'. it is just a convention.
 * 
 */

// var circle = {};
// circle.radius = 5;
// circle.area = function() {
// return this.radius * this.radius * Math.PI;
// }
// console.log(circle.area());
// var fn = circle.area;
// window.radius = 1;
// console.log(fn.call());
// console.log(fn.call(circle));
// -----------------------------------------------------
// separating instances from class
// var Circle = {
// area : function() {
// return this.radius * this.radius * Math.PI;
// }
// };
//
// var instance = {
// radius : 6
// };
// instance.__proto__ = Circle;
//
// console.log(instance.area());
// -----------------------------------------------------
// constructors
//
// function Circle(radius) {
// this.radius = radius;
// this.area = function() {
// return this.radius * this.radius * Math.PI;
// }
// }
//
// var instance = {};
// Circle.call(instance, 5);
// console.log(instance.area());
// // -or-
// var instance2 = new Circle(5);
// console.log(instance2.area());
//
// console.log(instance instanceof Object);
// console.log(instance2 instanceof Circle);
// -----------------------------------------------
// new operator
//
// function Class() {
// }
//
// var instance1 = new Class();
//
// var instance2 = {};
// instance2.constructor = Class;
// instance2.__proto__ = Class.prototype;
// Class.apply(instance2);
//
// console.log(instance1.constructor);
// console.log(instance2.constructor);
//
// console.log(instance1.__proto__);
// console.log(instance2.__proto__);
//
// console.log(instance1 instanceof Class);
// console.log(instance2 instanceof Class);
// ------------------------------------------------------------
// function Car(name, model) {
// this.name = name;
// this.model = model;
// }
//
// // Function Protoype
// Car.prototype.display = function() {
// console.log(this.name + "-->" + this.model);
// }
//
// var car1 = new Car('bmw', 'model-1');
// var car2 = new Car('audi', 'model-2');
//
// car1.display();
// car2.display();
// ------------------------------------------------------------
// Function Binding
function Greetor(s) {
	this.text = s
}

function Server() {
	this.getUser = function(fn) {
		var name = 'naga';
		fn(name);
	}
}
Greetor.prototype.greet = function(name) {
	alert(this.text + '  ' + name)
}
var greetor = new Greetor('hello');
var server = new Server();

function bind(fnThis,fn) {
	return function(){
		fn.apply(fnThis,arguments);
	}
	
}

server.getUser(bind(greetor,greetor.greet));












