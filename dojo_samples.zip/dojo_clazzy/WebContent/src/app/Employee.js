/**
 * 
 */

define([ 'dojo/_base/declare', 'dojo/_base/lang', './Person' ], function(
		declare, lang, Person) {

	var Employee = declare([ Person ], {

		salary : 0.0,

		constructor : function(cArgs) {
			lang.mixin(this, cArgs);
		},

		askForRaise : function() {
			return this.salary * 0.25;
		}

	});

	return Employee;

});