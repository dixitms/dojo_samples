/**
 * 
 */

var privatePropTest = function() {
	var p = [ 1, 2, 3 ];
	return {
		get : function() {
			return p
		},
		reverse : function() {
			p.reverse
		}
	}
}();