package com.bank.model;

public enum AccountStatus {

	ACTIVE, INACTIVE

}
