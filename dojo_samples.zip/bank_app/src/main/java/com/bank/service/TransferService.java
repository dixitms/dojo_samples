package com.bank.service;

import java.util.List;

import com.bank.model.Account;
import com.bank.repo.AccountRepository;

public interface TransferService {

	public List<Account> loadAllAccounts();

	public void tranfser(double amount, String fromAcc, String toAcc);
	
	public void setAccountRepository(AccountRepository accountRepository);

}
