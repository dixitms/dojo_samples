/**
 * 
 */

var newObj = {}; // Object.prototype
var newObj = new Object();// Object.prototype
var newObj = Object.create(Object.prototype);  // ECMSScript 5

//-----------------------------------------------------

function Base(){}
