/**
 * singleton
 */

var mySingleton = {
	prop1 : 'something',
	prop2 : 'something else',
	method1 : function() {
		console.log('helloworld');
	}
};

// ----------------------------------------------------------------------------

var mySingleton = function() {
	// private
	var priVar = 'somethong private';
	function showPrivate() {
		console.log(priVar);
	}
	// public
	return {
		pubVar : 'the public can see this!',
		publicMethod : function() {
			showPrivate();
		}
	}
};

var single = mySingleton();

// -------------------------------------------------------------------------------

var Singleton = (function() {
	var instantiated;
	function init() {
		return {
			publicMethod : function() {
				console.log('hello world');
			},
			publicProperty : 'test'
		};
	}
	return {
		getInstance : function() {
			if (!instantiated)
				instantiated = init();
			return instantiated;
		}
	}
})();

var single = Singleton.getInstance();

//------------------------------------------------------------------------------------