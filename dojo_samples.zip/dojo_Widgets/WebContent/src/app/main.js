/**
 * 
 */

define([ 'dojo/dom', './counter/CounterWidget', 'dojo/domReady!' ], function(
		dom, CounterWidget) {

	var app = {};

	app.counter1 = new CounterWidget({
		count : 10
	});
	app.counter2 = new CounterWidget({
		count : 10
	});

	var divEle = dom.byId('counters');
	app.counter1.placeAt(divEle);
	app.counter2.placeAt(divEle);

	// app.counter1.destroy();
	// app.counter1.destroyRecursive();

	// app.counter1.set('count',200);

});