
define([ 'dojo/store/JsonRest', 'dojo/store/Memory', 'dojo/store/Cache','dojo/domReady!' ],
	
function(JsonRest, Memory, Cache) {

	var jsonStore = new JsonRest({
		target : '../rest/users/',
		idProperty : 'id'
	});

	var memoryStore = new Memory({
		idProperty : 'id'
	});

	var store = new Cache(jsonStore, memoryStore);

	// Get an object by identity
	// store.get('123').then(function(user) {
	// console.log(user);
	// });
	//
	// store.get('123').then(function(user) {
	// console.log(user);
	// });

	// Query for objects with options

	// store.query('foo=bar', {
	// start : 10,
	// count : 10,
	// sort : [ {
	// attribute : 'baz',
	// descending : true
	// } ]
	// }).then(function(results) {
	// });

	// Store an object identified by identity
	// store.put({
	// foo : "bar"
	// }, {
	// id : 3
	// });

	// store.add({
	// name : 'Bush',
	// age : '31',
	// address : 'pune'
	// });

	// Remove an object by ID
	// store.remove(3);

});
