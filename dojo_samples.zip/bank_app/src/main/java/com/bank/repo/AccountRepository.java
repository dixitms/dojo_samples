package com.bank.repo;

import java.util.List;

import com.bank.model.Account;

public interface AccountRepository {
	
	public List<Account> findAll();

	public Account load(String num);

	public void update(Account account);

}
