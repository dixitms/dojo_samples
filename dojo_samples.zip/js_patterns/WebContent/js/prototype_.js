/**
 * 
 */

var someCar = {
	name : 'Mazda 3',
	drive : function() {
	}
};

var anotherCar=Object.create(someCar);
console.log(anotherCar.name);