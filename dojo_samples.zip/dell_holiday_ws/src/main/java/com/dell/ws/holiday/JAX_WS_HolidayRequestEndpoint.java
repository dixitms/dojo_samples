package com.dell.ws.holiday;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import com.dell.holiday.EmployeeType;
import com.dell.holiday.HolidayRequest;
import com.dell.holiday.HolidayType;

@WebService(name = "HumanResource", portName = "HumanResourcePort", serviceName = "HumanResourceService", targetNamespace = "http://mycompany.com/hr/definitions")
public class JAX_WS_HolidayRequestEndpoint {

	@WebMethod(operationName = "Holiday")
	public String holidayRequest(
			@WebParam(partName = "HolidayRequest", targetNamespace = "http://mycompany.com/hr/schemas") HolidayRequest request) {

		EmployeeType employee = request.getEmployee();
		HolidayType holiday = request.getHoliday();
		System.out.println("To" + employee.getFirstName() + " : From"
				+ holiday.getFrom() + ",- TO " + holiday.getTo()
				+ " Holiday approved.");

		return "Hello " + employee.getFirstName() + " ! Enjouy your Holiday";
	}
}
