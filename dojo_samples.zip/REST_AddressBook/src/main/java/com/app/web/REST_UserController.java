package com.app.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.app.model.Contact;
import com.app.model.ContactList;
import com.app.repo.ContactNotFoundException;
import com.app.repo.UserContactRepository;
import com.app.repo.UserNotFoundException;

/*
 *  uri: /users/{user}/contacts/{}/
 *  
 *  e.g : /users/naga/contacts
 * 
 */

@Controller
@RequestMapping(value = "/users")
public class REST_UserController {

	@Autowired
	private UserContactRepository repository;

	@RequestMapping(value = "/{userName}/contacts", produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE }, params = { "!name" })
	public ResponseEntity<ContactList> showAllContacts(
			@PathVariable(value = "userName") String userName)
			throws UserNotFoundException {
		List<Contact> contacts = repository.findAllContacts(userName);
		ContactList contactList = new ContactList();
		contactList.setContacts(contacts);
		return new ResponseEntity<ContactList>(contactList, HttpStatus.OK);
	}

	@RequestMapping(value = "/{userName}/contacts", produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE }, params = { "name" })
	public ResponseEntity<ContactList> showAllContactsByName(
			@PathVariable(value = "userName") String userName,
			@RequestParam("name") String name) throws UserNotFoundException {
		System.out.println("By Name: " + name);
		List<Contact> contacts = repository.findAllContacts(userName);
		ContactList contactList = new ContactList();
		contactList.setContacts(contacts);
		return new ResponseEntity<ContactList>(contactList, HttpStatus.OK);
	}

	@RequestMapping(value = "/{userName}/contacts/{id}", produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<Contact> showContacts(
			@PathVariable(value = "userName") String userName,
			@PathVariable(value = "id") Integer id)
			throws UserNotFoundException, ContactNotFoundException {
		Contact contact = repository.getContact(userName, id);
		return new ResponseEntity<Contact>(contact, HttpStatus.OK);
	}

	@RequestMapping(value = "/{userName}/contacts/{id}", consumes = { MediaType.APPLICATION_JSON_VALUE }, method = RequestMethod.PUT)
	public ResponseEntity<Void> addNewContact(
			@PathVariable(value = "userName") String userName,
			@RequestBody Contact contact) throws UserNotFoundException {
		contact.setId(999);
		repository.addNewContact(userName, contact);
		HttpHeaders headers = new HttpHeaders();
		headers.set("location",
				"http://localhost:8082/REST_AddressBook/users/naga/contacts/999");
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}

//	 @ExceptionHandler({ UserNotFoundException.class })
	// @ResponseStatus(reason="",value="")
	// public ResponseEntity<String> handleUNFE(UserNotFoundException unfe) {
	// return new ResponseEntity<String>("User Not Exist",
	// HttpStatus.NOT_FOUND);
	// }

}
