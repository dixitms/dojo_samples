/**
 * 
 */

define([ 'dojo/_base/declare', 'dojo/_base/lang' ], function(declare, lang) {

	var Person = declare(null, {

		name : 'No Name',
		age : null,
		residence : 'Universal',


	});

	return Person;

});