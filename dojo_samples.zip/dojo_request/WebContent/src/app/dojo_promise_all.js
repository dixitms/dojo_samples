/**
 * 
 */

define([ 'dojo/promise/first' ,'dojo/Deferred'], function(first,Deferred) {

	function googleReq() {
		var def = new Deferred();
		setTimeout(function() {
			def.resolve('Google Result');
		}, 5000);
		return def;
	}

	function yahooReq() {
		var def = new Deferred();
		setTimeout(function() {
			def.resolve('Yahoo Result');
		}, 7000);
		return def;

	}

	var def1 = googleReq();
	var def2 = yahooReq();

	first([ def1, def2 ]).then(function(results) {
		console.log(results.length);
		//console.log('all def finished...'+gResult+","+yResult);
	}, function(error) {
		console.log('error');
	});

});