/**
 * 'this' in JS
 */

/*
 * this ?
 * 
 * 
 * this --> obj , on which method invoked.
 */

var testObj = {
	x : 1,
	testMethod : function() {
		console.log('value of x = ' + this.x);
		var simulateThis=this;
		inner();
		function inner() {
			console.log('value of x = ' + simulateThis.x);
		}
	}

};
