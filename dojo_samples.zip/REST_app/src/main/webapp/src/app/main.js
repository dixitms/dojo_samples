
define(['app/JSON_REST_Store','dojo/domReady!' ], function() {

	var app = {};

	//
	
	return app;

});
