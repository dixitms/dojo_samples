package com.bank.service;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.bank.model.Account;
import com.bank.repo.AccountRepository;

public class TxrServUnitTest {

	private TransferService transferService;
	private AccountRepository accountRepository;

	@Before
	public void init() {
		transferService = new TransferServiceImpl();
		// accountRepository = new StubAccountRepository();
		accountRepository = EasyMock.createNiceMock(AccountRepository.class);
		transferService.setAccountRepository(accountRepository);
	}

	@Test
	public void txrTest() {

		String from = "1";
		String to = "2";

		double amount = 100.00;

		// ----------------------------------------------

		Account account = new Account();
		account.setNum("1");
		account.setBalance(100.00);

		EasyMock.expect(accountRepository.load(from)).andReturn(account);

		Account account2 = new Account();
		account2.setNum("2");
		account2.setBalance(100.00);

		EasyMock.expect(accountRepository.load(to)).andReturn(account2);

		 accountRepository.update(account);
		 accountRepository.update(account2);

		// ------------------------------------------------------

		EasyMock.replay(accountRepository);

		transferService.tranfser(amount, from, to);
		//
		// double expected = 200.00;
		// double actual = accountRepository.load(to).getBalance();

		EasyMock.verify(accountRepository);

		// Assert.assertEquals(String.valueOf(expected),
		// String.valueOf(actual));

	}

}
