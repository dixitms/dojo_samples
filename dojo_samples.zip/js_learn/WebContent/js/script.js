/**
 * 
 */

// alert("Hello i am JS");
/*
 * JS Variables
 * 
 */

// var x=5;
// x='js';
// console.log(typeof x);
// var x;
// console.log(x);
/*
 * JS - Types
 * 
 * a. primitive ( values ) b. objects
 * 
 * 1. primitive types
 * 
 * String , Number , Boolean , null , undefined
 * 
 * 2. objects
 * 
 * Object , Array , Function , etc......
 * 
 * 
 */

var a = "i am string";
var b = 'so am i';

var num1 = 100;
var num2 = 100.00;
var num3 = -100;

var okay = true;
var fail = false;

var foo = null;

var bar1 = undefined;
var bar2;

// -----------------------------------------------------------

var person = {};

person.firstName = "Naga";
person.lastName = "N";

console.log(person.firstName + " " + person.lastName);

// ------------------------------------------------------------

var person2 = {
	firstName : 'Indu',
	lastName : 'N'
}

console.log(person2.firstName + " " + person2.lastName);

// -------------------------------------------------------------

var people = {};

people['person1'] = person;
people.person2 = person2;

console.log(people['person1'].firstName);
console.log(people['person2'].firstName);

// console.log(typeof people);
// --------------------------------------------------------------

// Array

// creating an array with th constructor
var foo = new Array();

// create an array with the array literal syntax
var bar = [];

var foo = [ 100, 200 ];
console.log(foo[0]);
console.log(foo.length);

var bar = new Array(100);
console.log(bar[0]);
console.log(bar.length);

console.log(typeof bar);

var foo = [];

foo.push("a");
foo.push("b");

console.log(foo[0]);

foo.pop();

console.log(foo[0]);
console.log(foo[1]);

foo.unshift("z");

console.log(foo[0]);
console.log(foo[1]);

foo.shift();

console.log(foo[0]);
console.log(foo[1]);

// -----------------------------------------------

// Type checking in JS

var n = 5;
var s = "5";

console.log(n == s);

// ------------------------------------------------

var foo = 1;
var bar = "2";

console.log(foo + Number(bar));

// -------------------------------------------------

var x;
console.log(typeof x);

//---------------------------------------------------	







