/**
 * module
 * 
 */

// -------------------------------------------------------
// 1. by object literals
var myModule = {

	myProperty : 'someValue',

	myConfig : {
		useCaching : true,
		langauge : 'en'
	},

	myMethod : function() {
		console.log('i can haz functionality');
	}

};

// -------------------------------------------------------

// using IIFE

var module=()();

var counterModule = (function(a, b) {
	var counter = 0;
	return {
		incrementCounter : function() {
			return counter++;
		},
		resetCounter : function() {
			counter = 0;
		}
	}
})('a', 'b');

// var mod=testModule('a','b');

// ------------------------------------------------------------

var myRevealingModule = (function() {

	var name = 'naga';
	var age = '30';

	function setPerson() {
		name = 'naga Set';
	}
	function getPerson() {
		return name;
	}

	return {
		set : setPerson,
		get : getPerson
	};

})();

// -------------------------------------------------------------------
