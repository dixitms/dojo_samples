/**
 * 
 */

define([ 'dojo/topic', 'dojo/on', 'dojo/dom', 'dojo/_base/lang', 'dojo/domReady!' ], function(
		topic, on, dom,lang) {

	on(dom.byId('a'), 'click', function(e) {
		topic.publish('topicA', {
			prop : 'value'
		}, 'another');
	});

	on(dom.byId('b'), 'click', function(e) {
		topic.publish('topicB');
	});

	// ------------------------------------------------------

	var r1=topic.subscribe('topicA', function(arg1, arg2) {
		console.log('1. --> subscribed topicA ' + arg1.prop + ',' + arg2);
	});

	var r2=topic.subscribe('topicA', function() {
		console.log('2. --> subscribed topicA');
	});

	// -------------------------------------------------------

	// -------------------------------------------------------


	var ref=topic.subscribe('topicB', function() {
		console.log('subscribed topicB');
		ref.remove();
	});
	
	// --------------------------------------------------------
	
	var trainer={
			tnrName:'Naga',
			doTng:function(){
				console.log(this.tnrName+'--> Teaching DOJO');
			}
	};
	
	
	on(dom.byId('dojo'),'click',lang.hitch(trainer,'doTng'));
	
	
	
	
});



