/**
 * 
 */

define('js/employee', [ 'js/trainer' ], function(tnr) {

	return {
		doLearn : function() {
			tnr.doTeach();
			console.log('Emp learning JS');
		}
	}

});