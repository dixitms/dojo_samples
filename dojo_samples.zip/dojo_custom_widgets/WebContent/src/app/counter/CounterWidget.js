/**
 * 
 */
define([ 'dojo/_base/declare', 'dijit/_WidgetBase', 'dijit/_TemplatedMixin',
		'dojo/dom-construct', 'dojo/on', 'dojo/_base/lang',
		'dojo/text!./templates/CounterWidget.html', 'dijit/registry',
		'dijit/_WidgetsInTemplateMixin', 'dijit/Dialog' ],

function(declare, _WidgetBase, _TemplatedMixin, domConstruct, on, lang,
		template, registry, _WidgetsInTemplateMixin) {

	var CounterWidget = declare('app.count.CounterWidget', [ _WidgetBase,
			_TemplatedMixin, _WidgetsInTemplateMixin ], {

		count : 0,
		templateString : template,
		baseClass : 'counter',

		// Init
		// ---------------------------------------------------
		constructor : function() {
			console.log('constructor.....');
		},
		postMixInProperties : function() {
			// After instance , to do further init with widget properties
			console.log('postMixinProperties.....');
			this.inherited(arguments);
		},
		// buildRendering : function() {
		// // Create UI of widget ( DOM Node )
		// console.log('buildRendering.....');
		//
		// var bEle = domConstruct.create('button', {
		// innerHTML : 'Push Me'
		// });
		//
		// on(bEle, 'click', lang.hitch(this, 'increment'));
		//
		// this.domNode = bEle;
		// this.inherited(arguments);
		// },

		_setCountAttr : function(newCount) {
			console.log('setCount...' + newCount);
			this.count = newCount;
			this.cc.innerHTML = this.count;
		},
		_getCountAttr : function() {
			return this.count;
		},

		postCreate : function() {
			// final work with widget , before widget on live ( on page )
			// on(this.kickEle, 'click', lang.hitch(this, 'increment'));

			this.own(on(this.kickEle, 'click', lang.hitch(this, 'increment')));

			console.log('postCreate.....');
			this.inherited(arguments);
		},

		// Use ( on page )
		// ---------------------------------------------------------

		// Destroy
		// ----------------------------------------------------------
		destroyRecursive : function() {
			console.log('destroy.....');
			this.inherited(arguments);
		},
		increment : function() {

			console.log('increment...');
			this.count++;
			// this.cc.innerHTML = this.count

			if (this.count == 10) {
				// var popup = registry.byId('countAlert');
				// popup.show();
				this.countAlert.show();
			}

			this.set('count', this.count)

		}

	});

	return CounterWidget;

});