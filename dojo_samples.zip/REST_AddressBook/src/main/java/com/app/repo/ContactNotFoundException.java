package com.app.repo;

public class ContactNotFoundException extends Exception {

}
