package com.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bank.model.Account;
import com.bank.repo.AccountRepository;
import com.spring.AccRepoQualifier;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	@AccRepoQualifier(tech="HIBERNATE")
	private AccountRepository accountRepository;

	/* (non-Javadoc)
	 * @see com.bank.service.AccountService#getAccount(java.lang.String)
	 */
	@Override
	@Transactional
	public Account getAccount(String num) {
		return accountRepository.load(num);
	}
	
	
	@Override
	@Transactional
	public List<Account> getAllAccounts() {
		return accountRepository.findAll();
	}

}
