/**
 * 
 */

define([ 'dojo/_base/declare' ], function(declare) {

	var C = declare(null, {

		// var
		name : 'No Name',

		// method
		sayHello : function() {
			console.log(this.name + "--> saying hello");
		}

	});

	return C;

});