define(['dstore/Request', 'dgrid/OnDemandGrid' ], function(Rest,OnDemandGrid) {
	// Create an instance of OnDemandGrid referencing the store
	var grid = new OnDemandGrid({
		collection : new Rest({
			target : '../rest/users/'
		}),
		columns : {
			name : 'Name',
			age : 'Age',
			address : 'Address'
		}
	}, 'grid');

	grid.startup();
});