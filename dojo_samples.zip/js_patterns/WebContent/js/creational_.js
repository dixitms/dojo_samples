/**
 * creational pattern
 */

// 3-ways
var newObject = {}; // or
var newObject = Object.create(null); // or
var newObject = new Object();

// 1. dot syntax

newObject.someKey = 'Hello World'; // write properties
var key = newObject.someKey; // Access properties

// 2. square bracket systax
newObject['someKey'] = "Hello World";
var key = newObject['someKey'];
