/**
 * 
 */

define([ 'dojo/_base/declare' ], function(declare) {

	var A = declare(null, {

		'-chains-' : {
			init : 'after',
			destroy : 'before'
		// constructor : 'manual'
		},

		init : function() {
			console.log("A-init");
		},

		destroy : function() {
			console.log("A-Destroy");
		}

	});

	var B = declare(A, {

		init : function() {
			// this.inherited(arguments);
			console.log("B-init");
		},

		destroy : function() {
			console.log("B-Destroy");
			// this.inherited(arguments);
		}

	});

	var b = new B();

	b.init();
	b.destroy();

});