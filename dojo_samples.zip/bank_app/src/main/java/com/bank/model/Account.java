package com.bank.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
@Table(name = "ACCOUNTS", schema = "dell")
public class Account {

	@Id
	@Column(name = "NO")
	private String num;
	private String name;
	private double balance;

	@Enumerated(EnumType.STRING)
	private AccountStatus status;

	@XmlElement
	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	@XmlElement
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@XmlElement
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@XmlElement
	public AccountStatus getStatus() {
		return status;
	}

	public void setStatus(AccountStatus status) {
		this.status = status;
	}

}
