/**
 * 
 */

define([ 'dojo/_base/declare' ], function(declare) {

	var A = declare(null, {
		m1 : function() {
			console.log('A-old')
		},
		m2 : function() {
			console.log('A-old')
		}
	});

	var B = declare(null, {
		m2 : function() {
			this.inherited(arguments);
			console.log('B-old')
		},
		m3 : function() {
			this.inherited(arguments);
			console.log('B-old')
		}
	});

	var C = declare(null, {
		m3 : function() {
			this.inherited(arguments);
			console.log('C-old')
		},
		m4 : function() {
			this.inherited(arguments);
			console.log('C-old')
		}
	});

	var ABC = declare([ A, B, C ], {});

	var abc = new ABC();

	console.log(abc instanceof A); // true
	console.log(abc instanceof B); // false
	console.log(abc instanceof C); // false

	// abc.m1(); // m1 comes from A ( inherited )
	// abc.m2(); // m2 comes from B ( copied )
	// abc.m3(); // m3 comes from C ( copied )
	// abc.m4(); // m4 comes from C ( copied )

	A.extend({
		m1 : function() {
			console.log('A-New')
		},
		m2 : function() {
			console.log('A-New')
		}
	});

	B.extend({
		m2 : function() {
			console.log('B-New')
		},
		m3 : function() {
			console.log('B-New')
		}
	});
	C.extend({
		m3 : function() {
			console.log('C-New')
		},
		m4 : function() {
			console.log('C-New')
		}
	});

	// abc.m1();
	// abc.m2();
	// abc.m3();
	abc.m4();

});
