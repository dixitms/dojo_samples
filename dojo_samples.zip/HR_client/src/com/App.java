package com;

import java.math.BigInteger;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.mycompany.hr.definitions.HumanResource;
import com.mycompany.hr.definitions.HumanResourceService;
import com.mycompnay.hr.schemas.EmployeeType;
import com.mycompnay.hr.schemas.HolidayRequest;
import com.mycompnay.hr.schemas.HolidayResponse;
import com.mycompnay.hr.schemas.HolidayType;

public class App {

	public static void main(String[] args)
			throws DatatypeConfigurationException {

		HolidayRequest request = new HolidayRequest();

		HolidayType holiday = new HolidayType();
		DatatypeFactory factory = DatatypeFactory.newInstance();
		XMLGregorianCalendar from = factory
				.newXMLGregorianCalendar("2014-12-24");
		holiday.setStartDate(from);
		XMLGregorianCalendar to = factory.newXMLGregorianCalendar("2014-12-31");
		holiday.setEndDate(to);

		EmployeeType employee = new EmployeeType();
		employee.setNumber(new BigInteger("123"));
		employee.setFirstName("Naga");
		employee.setLastName("A");

		request.setHoliday(holiday);
		request.setEmployee(employee);
		
		//--------------------------------------------------------
		
		HumanResourceService hrService=new HumanResourceService();  // service
		HumanResource hr=hrService.getHumanResourcePort();
		
		
		HolidayResponse resp=hr.holiday(request);
		
		System.out.println("Reply : "+resp.getStatus());
		

		//--------------------------------------------------------
	}

}
