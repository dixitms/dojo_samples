/**
 * 
 */

define(function() {

	var priVar = 0;

	return {
		increment : function() {
			priVar++;
		},
		decrement : function() {
			priVar--;
		},
		getValue : function() {
			return priVar;
		}

	}

});