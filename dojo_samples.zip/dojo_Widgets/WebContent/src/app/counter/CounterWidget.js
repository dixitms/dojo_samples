/**
 * 
 */

define([ 'dojo/_base/declare', 'dijit/_WidgetBase', 'dojo/dom-construct',
		'dijit/_TemplatedMixin', 'dojo/text!./template/CounterWidget.html',
		'dojo/on', 'dojo/_base/lang' ],

function(declare, _WidgetBase, domConstruct, _TemplatedMixin, template, on,
		lang) {

	var Counter = declare([ _WidgetBase, _TemplatedMixin ], {

		count : 0,

		baseClass : 'counterWidget',

		templateString : template,

		constructor : function() {
			console.log('constructor....');
		},

		postMixInProperties : function() {
			console.log('postMixinProperties....');
		},

		// buildRendering : function() {
		// console.log('buildRendering....');
		// this.domNode = domConstruct.create('button', {
		// innerHTML : 'Push Me'
		// });
		// },

		_setCountAttr : function(initCount) {
			console.log('set....' + initCount);
			this.count = initCount;
		},

		postCreate : function() {
			console.log('postCreate....');
			this.cc.innerHTML = this.count;
			// this.own(on(this.cb, 'click', lang.hitch(this, 'increment')));
		},

		startup : function() {
			console.log('postCreate....');
		},
		increment : function() {
			// this.count+=this.count
			this.cc.innerHTML = ++this.count;
		}

	// destroy : function() {
	// console.log('destroy....');
	// this.inherited(arguments);
	// }

	});

	return Counter;

});