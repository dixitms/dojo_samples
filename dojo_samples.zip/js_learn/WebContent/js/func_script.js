/**
 * 
 */

// function dec
function foo() {
	// Do Something
}

// Named Function expression

var foo = function() {
	// Do Something
}

// Using Functions

// --------------------------------------------------

var greet = function(person, greeting) {
	var text = greeting + "," + person;
	console.log(text);
}

greet('naga', 'Hello');

// ---------------------------------------------------

var greet = function(person, greeting) {
	var text = greeting + "," + person;
	return text;
}

var r = greet('naga', 'Hello');
console.log(r);

// ------------------------------------------------------

var greet = function(person, greeting) {
	var text = greeting + "," + person;
	return function() {
		console.log(text);
	}

}

var greeting = greet('naga', 'hello');
greeting();

// -----------------------------------------------------------

// IIFE ( Immediatly-Invoked Function Expression )

(function() {
	var foo = "Hello World";
	console.log(foo);
})();

// Functions as Arguments

var myFn = function(fn) {
	var r = fn();
	console.log(r);
}

var getText = function() {
	return 'Hello World';
}

myFn(getText);
myFn(function() {
	return 'Hello World Again'
});

function abc() {
	var i, j;
	i = 1;
	j = 2
	console.log(i, +" " + j);
}



