/**
 * 
 */

define([ 'dojo/on', 'dojo/dom', 'dojo/request', 'dojo/dom-form',
		'dojo/Deferred', 'dojo/_base/array', 'dojo/domReady!' ], function(on,
		dom, request, domForm, Deferred, arrayUtil) {

	on(dom.byId('bEle'), 'click', function(e) {

		var def = request('ajax.txt', {

			// method : 'GET',

			// query : {
			// param1 : 'value1',
			// param2 : 'value2',
			// }

			method : 'POST',
			data : {
				param1 : 'value1',
				param2 : 'value2',
			},

			headers : {
				my_header_key : 'header_value'
			},
			timeout : 30,
			sync : true,
			preventCache : true,
			handleAs : 'text' // text , xml , json , javascript

		});

		//		
		// request.get(url,{});
		// request.post(url,{});
		//		

		def.then(function(data) {
			dom.byId('ajaxResult').innerHTML = data;
		}, function(error) {
			console.log(error);
		});

	});

	// ----------------------------------------------------------------

	on(dom.byId('personForm'), 'submit', function(event) {

		request('savePerson', {
			method : 'POST',
			data : domForm.toObject('personForm')
		});

		event.preventDefault();

	});

	// ----------------------------------------------------------------

	var def = new Deferred();

	var newDef = def.then(function(employees) {
		return arrayUtil.map(employees, function(emp) {
			// console.log(emp);
			return {
				name : emp.name
			}
		});
	}, function(error) {
		console.log(error);
	});

	var anotheNewDef = newDef.then(function(empNames) {
		return arrayUtil.map(empNames, function(nName) {
			console.log(nName);
			return {
				newName : 'HSBC-' + nName.name
			}
		});
	});

	anotheNewDef.then(function(hsbcNames) {
		arrayUtil.forEach(hsbcNames, function(hsbcName) {
			console.log(hsbcName);
		});
	});

	// Asynch.....
	var reqDef = request('emps.json', {
		handleAs : 'json'
	});

	reqDef.then(function(jsonData) {
		def.resolve(jsonData.employees);
	}, function(error) {
		def.reject(error);
	});

	// ---------------------------------------------------------------------

});
