/**
 * 
 */

 define(['dojo/_base/declare','dijit/Dialog'],function(declare,Dialog){
	 
	 var D=declare(Dialog,{
		 title:'HSBC- Hello World',
		 content:'Hello all , Welcome to dojo-world'
	 });
	 
	 return D;

 });