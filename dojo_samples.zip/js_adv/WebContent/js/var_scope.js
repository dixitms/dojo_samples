/**
 * 
 */

/*
 * var scope ----------
 * 
 * --> global scope var --> function scope var
 * 
 */

var x = 5; // global scope var
var y = 200;

function func() {
	var x = 10; // function scope var
	y = 20;
	console.log(x);
}
func();

console.log(x);

function func2() {
	console.log('Func-2 --> ' + y);
}

func2();
