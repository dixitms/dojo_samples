package com.app.repo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.app.model.User;

@Repository
public class UserRepository {

	private static Map<Integer, User> map = new HashMap<Integer, User>();

	static {

		User user = new User();
		user.setId(123);
		user.setName("Naga");
		user.setAge(31);
		user.setAddress("Pune");

		User user2 = new User();
		user2.setId(124);
		user2.setName("Indu");
		user2.setAge(26);
		user2.setAddress("Chennai");

		map.put(123, user);
		map.put(124, user2);

	}

	public User save(User user) {
		User u = map.put(user.getId(), user);
		return user;
	}

	public User findUser(Integer id) {
		return map.get(id);
	}

	public List<User> findAll() {
		return new ArrayList<User>(map.values());
	}

	public User remove(Integer id) {
		User u = map.remove(id);
		return u;
	}

	public User update(User user) {
		User u = map.put(user.getId(), user);
		return user;
	}

}
