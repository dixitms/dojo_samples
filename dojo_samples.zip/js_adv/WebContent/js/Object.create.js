/**
 * Object.create() -> static function
 * 
 */

var a = Object.create(null);
var a = Object.create({});
var a = Object.create(Object.prototype);

var obj1 = {
	p : [ 1, 2, 3 ],
	q : '123'
};

var obj2 = Object.create(obj1);


var parent = {
	x : 1,
	y : 2
};

var child = Object.create(parent);

function customCreate(obj) {
	var f = function() {
	};
	f.prototype = obj;
	return new f();
}

var child2 = customCreate(parent);







var vehicle={};
//var car=Object.create(vehicle);
function Car(){
}
Car.prototype=vehicle;
var car=new Car();

















