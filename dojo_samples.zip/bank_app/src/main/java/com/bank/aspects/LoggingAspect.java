package com.bank.aspects;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

// Aspect

@Aspect
@Component
public class LoggingAspect {

	private static Logger logger = Logger.getLogger(LoggingAspect.class);

	// @Before("execution(* com.bank.service.TransferServiceImpl.tranfser(..))")
	// public void doLogBeforeMethod(JoinPoint joinPoint) {
	// logger.info("log-Before: " + joinPoint.getSignature().toShortString());
	// }
	//
	// @AfterReturning(pointcut =
	// "execution(* com.bank.service.TransferServiceImpl.tranfser(..))",
	// returning = "r")
	// public void doLogAfterReturnMethod(JoinPoint joinPoint, Object r) {
	// logger.info("log-AfterReturning: "
	// + joinPoint.getSignature().toShortString());
	// }
	//
	// @AfterThrowing(pointcut =
	// "execution(* com.bank.service.TransferServiceImpl.tranfser(..))",
	// throwing = "e")
	// public void doLogAfterThrowing(JoinPoint joinPoint, Throwable e) {
	// logger.info("log-@AfterThrowing: "
	// + joinPoint.getSignature().toShortString());
	// }
	//
	// @After("execution(* com.bank.service.TransferServiceImpl.tranfser(..))")
	// public void doLogAfter(JoinPoint joinPoint) {
	// logger.info("log-@AfterThrowing: "
	// + joinPoint.getSignature().toShortString());
	// }
	//
	//

	//@Around("execution(* *(..))")
	public void doLogAfter(ProceedingJoinPoint joinPoint) {

		try {
			logger.info("log-@Before: "
					+ joinPoint.getSignature().toShortString());
			joinPoint.proceed();
			logger.info("log-@AfterReturning: "
					+ joinPoint.getSignature().toShortString());

		} catch (Throwable e) {
			logger.info("log-@AfterThrowing: "
					+ joinPoint.getSignature().toShortString());

		}
		
		logger.info("log-@After: " + joinPoint.getSignature().toShortString());

	}

}
