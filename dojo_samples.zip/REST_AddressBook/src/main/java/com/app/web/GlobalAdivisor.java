package com.app.web;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.app.repo.UserNotFoundException;

@ControllerAdvice
public class GlobalAdivisor {

	@ExceptionHandler({ UserNotFoundException.class })
	// @ResponseStatus(reason = "", value = "")
	public ResponseEntity<String> handleUNFE(UserNotFoundException unfe) {
		return new ResponseEntity<String>("User Not Exist",
				HttpStatus.NOT_FOUND);
	}

}
