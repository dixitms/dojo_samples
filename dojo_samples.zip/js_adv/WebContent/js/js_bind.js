/**
 * 
 */

function extendSerialize(obj) {
	for (prop in obj) {
		this[prop] = obj[prop];
	}
	return JSON.stringify(this);
}

var o1 = {
	x : 100,
	y : 200
};
var o2 = {
	p : 'js',
	q : true
}
var o3={name:'naga'}


var o1BindedFun = extendSerialize.bind(o1);

o1BindedFun(o2);
o1BindedFun(o3);



