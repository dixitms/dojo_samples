package com;

import com.bill.BillingImpl;
import com.pm.PriceMatrix;
import com.pm.PriceMatrixImpln_v1;
import com.pm.PriceMatrixImpln_v2;

public class App {

	public static void main(String[] args) {

		// init
		//--------------------------------------------
		
		PriceMatrix priceMatrix=new PriceMatrixImpln_v1();
		PriceMatrix priceMatrix2=new PriceMatrixImpln_v2();
		
		BillingImpl billComp = new BillingImpl(priceMatrix2);
		
		//--------------------------------------------

		// use
		String[] cart = { "123", "124" };
		double total = billComp.getTotalPrice(cart);

		System.out.println(total);

		// destroy
		billComp = null;

	}

}
