package com.bank.aspects;

import org.aspectj.lang.annotation.Pointcut;

public class DellServicePointcuts {

	@Pointcut("execution(* *(..))")
	public void txrService() {
	}

}
