package com.bank.service;


import java.util.List;

import com.bank.model.Account;

public interface AccountService {

	public abstract Account getAccount(String num);
	public abstract List<Account> getAllAccounts();
	

}