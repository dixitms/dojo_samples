/**
 * 
 */

define([ 'dojo/on', 'dojo/dom', 'dojo/Deferred', 'dojo/_base/array',
		'dojo/request' ], function(on, dom, Deferred, arrayUtil, request) {

	// Create a deferred
	var deferred = new Deferred();

	// Set up the callback and errback for the deferred
	deferred.then(function(resp) {
		arrayUtil.forEach(resp, function(employee) {
			console.log(employee);
		});
	}, function(err) {
		console.log(err);
	});

	// Send an HTTP request
	request.get('users.json', {
		handleAs : 'json'
	}).then(function(response) {
		// Resolve when content is received
		deferred.resolve(response.employees);
	}, function(error) {
		// Reject on error
		deferred.reject(error);
	});

});