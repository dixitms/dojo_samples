package com.bank.web;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bank.exceptions.AccountNotFoundException;
import com.bank.service.TransferService;

@Controller
public class TxrController {

	@Autowired
	private TransferService transferService;

	@RequestMapping(value = "/txr", method = RequestMethod.POST)
	public ModelAndView doTxr(@RequestParam double amount,
			@RequestParam String fromAcc, @RequestParam String toAcc,
			HttpSession session) {

		transferService.tranfser(amount, fromAcc, toAcc);

		ModelAndView mav = new ModelAndView();
		mav.addObject("msg", "Txr successful");
		mav.setViewName("txrStatus");

		return mav;

	}

	// @ExceptionHandler({ AccountNotFoundException.class })
	// public ModelAndView handleANFE(AccountNotFoundException anfe) {
	//
	// ModelAndView mav = new ModelAndView();
	// mav.addObject("exception", anfe);
	// mav.setViewName("txrStatus");
	//
	// return mav;
	//
	// }

}
