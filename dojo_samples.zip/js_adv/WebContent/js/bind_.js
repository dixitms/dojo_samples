/**
 * bind
 * 
 */

function area() {
	var r = this.radius * this.radius * Math.PI;
	console.log(r);
}

var circle1 = {
	radius : 5
};

var newArea = area.bind(circle1);
newArea();

function customBind(fn, obj) {
	return function() {
		return fn.apply(obj, arguments);
	}
}

var newArea2 = customBind(area, circle1);
newArea2();
