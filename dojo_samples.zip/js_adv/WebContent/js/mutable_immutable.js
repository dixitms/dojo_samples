/**
 * 
 */

/*
 * primitive-type ---> immutable; reference-type ( array , obj , ...)
 * --->mutable
 * 
 */

var person = {
	name : 'A',
	salary : 1000.00
};

function changeSalary(pSalary) {
	pSalary += 2000.00;
}
changeSalary(person.salary);

console.log(person.salary);

//--------------------------------------

var emp={name:'Abc'};
emp.name=emp.name.toUpperCase();
console.log(emp.name);




