package com.bank.repo;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.bank.model.Account;
import com.spring.AccRepoQualifier;

//@Component
//@Repository
//@AccRepoQualifier(tech="JDBC")
public class JDBCAccountRepository implements AccountRepository {

	private DataSource dataSource;

	@Autowired
	public JDBCAccountRepository(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
		System.out.println("JDBCAccRep bean created by injecting DS");
	}

	public Account load(String num) {
		// TODO Auto-generated method stub
		return null;
	}

	public void update(Account account) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Account> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
