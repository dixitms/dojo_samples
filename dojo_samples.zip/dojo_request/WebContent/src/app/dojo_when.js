/**
 * 
 */

// dojo/when

define([ 'dojo/request', 'dojo/when', 'dojo/Deferred' ], function(request,when, Deferred) {

	function asynchProcess() {
		var def = new Deferred();
		setTimeout(function() {
			def.resolve('asynch');
		}, 5000);
		return def;
	}

	function synchProces() {
		return "synch";
	}

	// var r=asynchProcess();
	var r = synchProces();

	when(r, function(value) {
		console.log('resolved...');
	}, function(error) {
		console.log('rejected...');
	}, function(update) {
		console.log('In progress...');
	});

});



