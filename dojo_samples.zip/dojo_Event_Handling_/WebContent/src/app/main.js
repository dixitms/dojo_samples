/**
 * 
 */

define([ 'dojo/on', 'dojo/dom', 'dojo/query', 'dojo/_base/declare',
		'dojo/Evented', 'dojo/domReady!' ], function(on, dom, query, declare,
		Evented) {

	/*
	 * on(target,eventType,handler);
	 * 
	 */

	// var actionButton = document.getElementById('actionButton'); //
	var actionButton = dom.byId('actionButton');
	var disableButton = dom.byId('dEle');
	var enableButton = dom.byId('eEle');

	// on(actionButton, 'click,focus', function(event) {
	// console.log('button clicked');
	// });

	// pause event

	var buttonHandler = on.pausable(actionButton, 'click', function(event) {
		console.log('Handling....');
	});

	on(disableButton, 'click', function(event) {
		buttonHandler.pause();
	});

	on(enableButton, 'click', function(event) {
		buttonHandler.resume();
	});

	// ----------------------------------------------------------

	on.once(dom.byId('once'), 'click', function(event) {
		console.log('Once Handler...');
	});

	// ------------------------------------------------------------

	var handlerRef = on(dom.byId('remove'), 'click', function(event) {
		console.log('After this ill remove handler');
		// by condition
	});

	handlerRef.remove();

	// ------------------------------------------------------------------

	// use event-delegation to listen for events

	on(document, '.myClass:click', function() {
		console.log('document : Event handling - click ' + this.id);
	});

	// ------------------------------------------------------------------------

	var Trainer = declare([ Evented ], {
		name : '',
		doTeach : function() {
			console.log(this.name + "--> Teaching DOJO");
			this.emit('trainer-event', {
				what : 'break'
			});
		}
	});

	var tnr = new Trainer();
	tnr.name = 'Naga';

	
	
	on(tnr,'trainer-event',function(tEvent){
		console.log('Trainer_event -->'+tEvent.what);
	})
	
	tnr.doTeach();
	

});




