/**
 * 
 */

define([ 'dojo/aspect', 'dojo/domReady!' ], function(aspect) {

	var rand = {
		getNumber : function(min, max) {
			return Math.floor(Math.random() * (max - min + 1)) + min;
		}
	}
	//
	// aspect.after(rand, 'getNumber', function(result) {
	// console.log('actual result :' + result);
	// return 5;
	// });

	// aspect.before(rand, 'getNumber', function(min, max) {
	// console.log('original args :' + min + ',' + max);
	// return [ 5, 15 ];
	// });

	aspect.around(rand, 'getNumber', function(originalFunc) {
		return function(min, max) {
			if (min === max) {
				console.log('not calling original funcc');
				return min;
			}
			return originalFunc(min, max);
		}
	});

	console.log('returned result :' + rand.getNumber(1, 10));
	
	
	

});
