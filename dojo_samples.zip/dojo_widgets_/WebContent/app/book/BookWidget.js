/**
 * 
 */
define([ "dojo/_base/declare",
         "dojo/_base/fx",
         "dojo/_base/lang",
         "dojo/dom-style",
         "dojo/mouse",
         "dojo/on", 
         "dijit/_WidgetBase",
         "dijit/_TemplatedMixin",
         "dojo/text!./templates/BookWidget.html"],
		function(declare, baseFx, lang, domStyle, mouse, on, _WidgetBase, _TemplatedMixin, template) {

			return declare([_WidgetBase, _TemplatedMixin], {
				
				name:'No Name',
				price:0.0,
				author:'No Author',
				desc:'',
				front:require.toUrl('./app/book/images/book.png'),
				
				templateString:template,
				
				baseClass:'bookWidget',
				
				mouseAnim:null,
				
				baseBackgroundColor: "#fff",
		        mouseBackgroundColor: "#def",
		        
		        
		        postCreate:function(){
		        	var domNode = this.domNode;
		        	this.inherited(arguments);
		        	domStyle.set(domNode, "backgroundColor", this.baseBackgroundColor);
		        	
		        	this.own(
		        	        on(domNode, mouse.enter, lang.hitch(this, "_changeBackground", this.mouseBackgroundColor)),
		        	        on(domNode, mouse.leave, lang.hitch(this, "_changeBackground", this.baseBackgroundColor))
		        	       );
		        },
		        
		        _changeBackground: function(newColor) {
		            // If we have an animation, stop it
		            if (this.mouseAnim) {
		                this.mouseAnim.stop();
		            }
		         
		            // Set up the new animation
		            this.mouseAnim = baseFx.animateProperty({
		                node: this.domNode,
		                properties: {
		                    backgroundColor: newColor
		                },
		                onEnd: lang.hitch(this, function() {
		                    // Clean up our mouseAnim property
		                    this.mouseAnim = null;
		                })
		            }).play();
		            
		        },
		        
		        
		        _setFrontAttr: function(imagePath) {
		            if (imagePath != "") {
		                this._set("front", imagePath);
		                
		                this.frontNode.src = imagePath;
		            }
		        }
		        
		        
				
			});
			
			
		});