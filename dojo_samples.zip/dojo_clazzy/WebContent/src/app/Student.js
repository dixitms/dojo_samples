/**
 * 
 */

define([ 'dojo/_base/declare' ], function(declare) {

	var Student = declare(null, {

		// instance var

		// primtive -var

		name : '',
		// count : 0,

		// reference-var
		arrayVar : undefined,

		constructor : function() {
			this.arrayVar = [];
		},

		sayHello : function() {
			++Student.count;
			console.log(this.name + "--->" + Student.count);
		}

	});

	Student.count = 0;

	return Student;

});