/**
 * 
 */

/*
 * array= zero-index , ordered list values.
 * 
 */

var myArray1 = new Array("hello", "world");
var myArray2 = [ "hello", "world" ];

var myArray = [];
myArray.push("hello");
myArray.push("world");
myArray[3] = "!";

console.log(myArray[2]);

// Array Methods and Properties
// ------------------------------------

var myArray = [ "hello", "world", "!" ];
console.log(myArray.length);

// .concat()

var myArray = [ 1, 2, 3, 4, 5 ];
var myOtherArray = [ 6, 7, 8, 9, 10 ];

var wholeArray = myArray.concat(myOtherArray);

console.log(wholeArray.length);

// .join()

var myArray = [ "hello", "world", "!" ];

console.log(myArray.join(" "));

// push() , pop()

// reverse()

// shift() removes first element of an array

// slice()

var myArray = [ 0, 7, 8, 5 ];
// console.log(myArray.slice(3));

// splice(index,lentgh,values)

myArray.splice(1, 2, 1, 2, 3, 4);
console.log(myArray);

// sort()

var myArray = [ 0, 7, 8, 5 ];

function desc(a, b) {
	return b - a;
}

myArray.sort(desc);

console.log(myArray);

// -------------------------------------------

// forEach()

var myArray = [ 1, 2, 3, 4, 5 ];

function printEle(e) {
	console.log(e);
}
function printEleAndIndex(e,index) {
	console.log(index+'-->'+e);
}
function negateArray(e,index,refArray) {
	refArray[index]=-e;
}

myArray.forEach(negateArray);
console.log(myArray);

//----------------------------------------------











