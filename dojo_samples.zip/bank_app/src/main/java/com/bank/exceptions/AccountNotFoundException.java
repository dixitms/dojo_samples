package com.bank.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

//@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "No Such Account")
public class AccountNotFoundException extends RuntimeException {

	private String num;

	public void setNum(String num) {
		this.num = num;
	}

	@Override
	public String getMessage() {
		return "Account-" + this.num + " ! Not Exist";
	}

}
