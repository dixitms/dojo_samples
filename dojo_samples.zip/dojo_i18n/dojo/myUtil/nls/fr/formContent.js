define(
    {
        invalidMessageName: "Un seul mot, pas de num&#233;ros autoris&#233;s",
        missingMessageName: "Cette entr&#233;e est n&#233;cessaire. S'il vous pla&#238;t entrez un mot, pas de num&#233;ros autoris&#233;s",
        invalidMessageTelephone: "Seuls les num&#233;ros autoris&#233;s dans ce format ###-###-####, ##########",
        missingMessageTelephone: "Cette entr&#233;e est n&#233;cessaire. S'il vous pla&#238;t entrez un num&#233;ro de t&#233;l&#233;phone",
        fname: "Pr&#233;nom",
        lname: "Nom de Famille",
        telephone: "Numero de T&#233;l&#233;phone",
        submitButtonLabel: "Soumettre",
        submitSuccessMessage: "Formulaire soumis avec succ&#232;s",
        page1 : "dojo/myUtil/nls/fr/templates/page1.html",
        page2 : "dojo/myUtil/nls/fr/templates/page2.html",
        page3 : "dojo/myUtil/nls/fr/templates/page3.html",
        page1Button: "Notre Caf&#233;",
        page2Button: "Notre Th&#233;",
        page3Button: "Notre Juis",
        openingMessage: "L'ouverture: ",
        placeHolder: "Enter Value ( fr )",
    }
);