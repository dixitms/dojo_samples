package com.bank.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bank.exceptions.AccountNotFoundException;
import com.bank.model.Account;
import com.bank.repo.AccountRepository;
import com.spring.AccRepoQualifier;

@Service("txrServ")
public class TransferServiceImpl implements TransferService {

	// private static Logger logger = Logger.getLogger(TransferService.class);

	private AccountRepository accountRepository;

	@Autowired(required = false)
	@AccRepoQualifier(tech = "HIBERNATE")
	public void setAccountRepository(AccountRepository accountRepository) {
		this.accountRepository = accountRepository;
		System.out.println("AccRep injected to TxrServ bean");
	}

	@Transactional(value = "hibTxnManager", isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED, rollbackFor = { RuntimeException.class })
	public void tranfser(double amount, String fromAcc, String toAcc) {

		// logger.info("Txr initiated.....");

		// load fromAcc
		Account fromAccount = accountRepository.load(fromAcc);

		// load toAcc
		Account toAccount = accountRepository.load(toAcc);

		if (fromAccount == null) {

			AccountNotFoundException ex = new AccountNotFoundException();
			ex.setNum(fromAcc);

			throw ex;
		}

		// debit
		fromAccount.setBalance(fromAccount.getBalance() - amount);

		// credit
		toAccount.setBalance(toAccount.getBalance() + amount);

		// update fromAcc
		accountRepository.update(fromAccount);

		// update toAcc
		accountRepository.update(toAccount);

		// ----------------------------------------------------------
		// System.out.println("------------------------------------------");
		// // load fromAcc
		// fromAccount = accountRepository.load(fromAcc);
		// System.out.println("From Account Bal:" + fromAccount.getBalance());
		//
		// // load toAcc
		// toAccount = accountRepository.load(toAcc);
		// System.out.println("To Account Bal:" + toAccount.getBalance());
		// System.out.println("------------------------------------------");
		// ----------------------------------------------------------

	}

	@Transactional(readOnly = true)
	@Override
	public List<Account> loadAllAccounts() {
		return accountRepository.findAll();

	}

}
