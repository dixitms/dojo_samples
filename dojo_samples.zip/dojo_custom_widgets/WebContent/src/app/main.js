/**
 * 
 */

define([ 'app/counter/CounterWidget' ], function(CounterWidget) {

	var app = {};

	// app.counter1 = new CounterWidget();
	// app.counter2 = new CounterWidget({count:10});
	//
	// app.counter1.placeAt(document.body);
	// app.counter2.placeAt(document.body);

	// app.counter1.destroyRecursive();

	// app.counter1.set('count',20);

	return app;

});