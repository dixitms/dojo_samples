/**
 * 
 */

define([ 'dojo/_base/declare', 'dijit/_WidgetBase', 'dijit/_TemplatedMixin',
		'dojo/dom-construct', 'dojo/on', 'dojo/_base/lang',
		'dojo/text!./templates/Counter.html' ],

function(declare, _WidgetBase, _TemplatedMixin, domConstruct, on, lang,
		template) {

	return declare([ _WidgetBase, _TemplatedMixin ], {

		_i : 0,

		templateString : template,

		constructor : function() {
			console.log('con inviked.....');
		},

		postMixInProperties : function() {
			console.log('postMixinProperties invoked....');
		},

		// buildRendering : function() {
		// this.domNode = domConstruct.create('button', {
		// innerHTML : 'Push Me'
		// });
		// console.log('buildRendering invoked....');
		// },

		postCreate : function() {
			console.log('postCreate invoked..');
			this.own(on(this.push, 'click', lang.hitch(this, '_increment')));
		},

		destroy : function() {
			this.inherited(arguments);
			console.log('destroy invoked....');
		},

		_increment : function() {
			console.log('increment called....');
			this.counter.innerHTML = ++this._i;
		}

	});

});