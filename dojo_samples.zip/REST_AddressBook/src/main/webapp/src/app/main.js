/**
 * 
 */

define([ 'dojo/store/Memory', 'dojo/store/JsonRest', 'dojo/domReady!' ],
		function(Memory, JsonRest) {

			var cdata = [ {
				id : 123,
				name : 'naga',
				age : 31
			}, {
				id : 124,
				name : 'indu',
				age : 26
			} ];

			var store = new Memory({
				data : cdata
			});

			// ---------------------------

			var c = store.get(123);
			// console.log(c);

			// ----------------------------

			store.query({
				age : 31
			}).forEach(function(c) {
				// console.log(c);
			});

			// -----------------------------

			store.query(function(obj) {
				return obj.age < 30;
			}).forEach(function(o) {
				// console.log(o);
			});

			// -----------------------------

			store.put({
				id : 124,
				name : 'indumathy'
			});

			store.remove(124);

			// --------------------------------------------------

			var restStore = new JsonRest({
				target : '../rest/users/naga/contacts/'
			});

			// Get an object identity

			var def = restStore.get(123);
			def.then(function(contact) {
				console.log(contact);
			});

			// Query for an object with options

			// restStore.query('name=indu',{
			// start : 10,
			// count : 10,
			// sort : [ {
			// attribute : 'name',
			// descending : true
			// } ]
			// });

			var contact = {
				name : 'HSBC',
				age : 10,
				email : 'hsbc@hsbc.com',
				fav : true
			};

			restStore.put(contact,{id:125});
			
			
			

		});
