define([ 'dojo/store/Memory', 'dojo/domReady!' ], function(Memory) {

		var someData = [
		{id:1, name:"One"},
		{id:2, name:"Two"}
		];

		var store = new Memory({data: someData});
		
		console.log(store.get(1));
		
		console.log(store.query({name:"One"}));
		
		store.query(function(object){
		    return object.id > 1;
		}) // Pass a function to do more complex querying

		store.query({name:"One"}, {sort: [{attribute: "id"}]}) // Returns query results and sort by id
		
		store.put({id:3, name:"Three"}); // store the object with the given identity
		
		store.remove(3); // delete the object

});
