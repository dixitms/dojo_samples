/**
 * 
 */
define([ 'dojo/_base/declare',
         'dijit/_WidgetBase',
         'dijit/_TemplatedMixin',
         'dojo/text!./templates/EmployeeWidget.html',
         'dojo/mouse',
         'dojo/_base/lang',
         'dojo/_base/fx',
         'dojo/on',
         'require'
         ],

function(declare, _WidgetBase, _TemplatedMixin,template,mouse,lang,baseFx,on,require) {

	return declare([ _WidgetBase, _TemplatedMixin ], {
		
		// variables
		
		templateString:template,
		
		firstName:'',
		lastName:'',
		pic:require.toUrl('./images/avatar.png'),
		
		baseBackgroundColor:"#fff",
		mouseBackgroundColor:"#f00",
			
		postCreate:function(){
			
			this.own(
			on(this.domNode,mouse.enter,lang.hitch(this,'_changeBackground',this.mouseBackgroundColor)),
			on(this.domNode,mouse.leave,lang.hitch(this,'_changeBackground',this.baseBackgroundColor))
			);
			
			this.inherited(arguments);
		},
		
		_changeBackground:function(newColor){
			
			var mouseAni=baseFx.animateProperty({
				node:this.domNode,
				properties:{
					backgroundColor:newColor
				}
				
			});
			
			mouseAni.play();
			
		},
		
		_setPicAttr:function(imgPath){
			
			if(imgPath!=""){
				this.picNode.src=imgPath;
			}
			
		}
		
		
	});

});