package com.bill;

import com.pm.PriceMatrix;

/*
 * 
 *  performance & design issue
 *  ---------------------------
 *  
 *  1. too many same dependencies.
 *  
 *     slow , memory , too many resources used..
 *  
 *  2. tight-coupling  ( ' closed for modification , open for Extension )
 *  
 *     can't extend easily.
 *  
 *  3. unit-testing not possible.
 *  
 *     bug fix slow , dev slow
 * 
 * 
 *   why these issues ?
 *   
 *   --> dependent's class creating its own dependency.
 *   
 *   soln :
 *   
 *   --> dont create dependency in dependent class, do lookup
 *   
 *   Limitation of lookup
 *   
 *   --> location tight-coupling
 *   
 *   best soln :
 *   
 *   --> dont create , dont find , ' Get/Inject by some-one' ( IOC )
 *   
 *   
 *   how to implement IOC >
 *   
 *   by 'Dependency Injection '
 *   
 *     types:
 *     
 *     --> constructor DI
 *     --> setter
 *   
 *   
 * 
 * 
 */

public class BillingImpl {

	PriceMatrix priceMatrix;

	public BillingImpl(PriceMatrix priceMatrix) {
		super();
		this.priceMatrix = priceMatrix;
	}

	public double getTotalPrice(String[] cart) {

		double totalPrice = 0.0;

		// priceMatrix = new PriceMatrixImpln_v1();

		for (String item : cart) {
			totalPrice += priceMatrix.getprice(item);
		}
		return totalPrice;

	}

}
