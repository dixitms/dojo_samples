@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.mycompnay.com/hr/schemas", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.mycompnay.hr.schemas;
