package com.pm;

public class PriceMatrixImpln_v1 implements PriceMatrix {
	
	

	/* (non-Javadoc)
	 * @see com.pm.PriceMatrix#getprice(java.lang.String)
	 */
	@Override
	public double getprice(String item) {
		// code..
		return 100.00;
	}

}
