@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.webserviceX.NET/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package net.webservicex;
