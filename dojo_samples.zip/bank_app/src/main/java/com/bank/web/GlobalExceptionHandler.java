package com.bank.web;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.bank.exceptions.AccountNotFoundException;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler({ AccountNotFoundException.class })
	public ModelAndView handleANFE(AccountNotFoundException anfe) {

		ModelAndView mav = new ModelAndView();
		mav.addObject("exception", anfe);
		mav.setViewName("txrStatus");

		return mav;

	}

	@ResponseStatus(value = HttpStatus.CONFLICT, reason = "integrirty violation")
	@ExceptionHandler(DataIntegrityViolationException.class)
	public void conflict() {

	}

	@ExceptionHandler({ SQLException.class, DataAccessException.class })
	public String dataError() {

		return "dbError";
	}

	@ExceptionHandler({ Exception.class })
	public ModelAndView hanadleError(HttpServletRequest req) {

		StringBuffer url = req.getRequestURL();

		// log;

		ModelAndView mav = new ModelAndView();

		return mav;
	}

}
