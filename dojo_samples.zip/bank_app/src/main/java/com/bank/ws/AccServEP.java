package com.bank.ws;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public class AccServEP {

	@WebMethod
	public void name() {

	}

}
