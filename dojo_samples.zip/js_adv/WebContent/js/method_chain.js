/**
 * Method-Chain
 */

var person = {
	name : 'naga',
	address : {
		city : 'bangalore',
		country : 'india'
	},
	nameToUpperCase : function() {
		this.name=this.name.toUpperCase();
		return this;
	},
	countryToUpperCase:function() {
		this.name=this.address.country.toUpperCase();
		return this;
	}

};

person.nameToUpperCase().countryToUpperCase();










