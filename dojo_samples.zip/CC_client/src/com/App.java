package com;

import net.webservicex.Currency;
import net.webservicex.CurrencyConvertor;
import net.webservicex.CurrencyConvertorSoap;

public class App {

	public static void main(String[] args) {

		// ---------------------------------------

		CurrencyConvertor cc = new CurrencyConvertor();
		CurrencyConvertorSoap port = cc.getCurrencyConvertorSoap();

		// --------------------------------------------------------------

		double rate = port.conversionRate(Currency.USD, Currency.INR);

		System.out.println("Rate :" + rate);

		//-----------------------------------------------------------------
	}

}
