package com.bank.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bank.model.Account;
import com.bank.repo.AccountRepository;

public class StubAccountRepository implements AccountRepository {

	private static Map<String, Account> accounts = new HashMap<String, Account>();

	static {

		Account account = new Account();
		account.setNum("1");
		account.setBalance(100.00);

		Account account2 = new Account();
		account2.setNum("2");
		account2.setBalance(100.00);

		accounts.put("1", account);
		accounts.put("2", account2);
	}

	@Override
	public Account load(String num) {
		return accounts.get(num);
	}

	@Override
	public void update(Account account) {
		accounts.put(account.getNum(), account);
	}

	@Override
	public List<Account> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
