/**
 * 
 */

define([ './Dialog','dojo/domReady!' ], function(Dialog) {

	var app = {};

	app.dialog = new Dialog().placeAt(document.body);
	
	app.dialog.startup(); // later
	
	app.dialog.show();
	
	return app;

});