package com.bank.ws;

import org.example.account.EnumAccountStatus;
import org.example.accountservice.AccountDetRequest;
import org.example.accountservice.AccountDetResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.bank.model.Account;
import com.bank.repo.AccountRepository;
import com.bank.service.AccountService;
import com.spring.AccRepoQualifier;

@Endpoint
public class AccountServiceEndpoint {

	@Autowired
	private AccountService accountService;

	private static final String TARGET_NAMESPACE = "http://www.example.org/AccountService";

	@Transactional
	@PayloadRoot(namespace = TARGET_NAMESPACE, localPart = "AccountDetRequest")
	public @ResponsePayload AccountDetResponse getAccountDet(
			@RequestPayload AccountDetRequest request) {

		Account account = accountService.getAccount(request.getAccountNumber());
		AccountDetResponse response = new AccountDetResponse();

		org.example.account.Account acc = new org.example.account.Account();
		acc.setAccountNumber(account.getNum());
		acc.setAccountName(acc.getAccountName());
		acc.setAccountBalance(account.getBalance());
		acc.setAccountStatus(EnumAccountStatus.ACTIVE);

		response.setAccountDetails(acc);

		return response;
	}

}
