/**
 * 
 */

define([ 'dojo/_base/declare', 'dojo/_base/lang', './Employee' ], function(
		declare, lang, Employee) {

	var Boss = declare(Employee, {

		// override
		askForRaise : function() {
			return this.inherited(arguments) + this.salary * 0.50;
		}

	});

	return Boss;

});