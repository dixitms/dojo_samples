/**
 * 
 */

var trainer = {
	name : 'Nagabhushanam',
	doTeach : function() {
	console.log(this.name+'-> Teaching JS');
	}

};

trainer.doTeach();
console.log(trainer.name);