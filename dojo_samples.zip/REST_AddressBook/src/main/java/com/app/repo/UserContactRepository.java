package com.app.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.app.model.Contact;
import com.app.model.User;

@Repository
public class UserContactRepository {

	private static User user = new User();

	static {
		user.setUserName("naga");

		Contact contact1 = new Contact();
		contact1.setId(123);
		contact1.setName("Indu");

		user.getContacts().add(contact1);
	}

	// DAO

	public Contact getContact(String userName, Integer id)
			throws UserNotFoundException, ContactNotFoundException {
		if (userName.equals(user.getUserName())) {
			for (Contact contact : user.getContacts()) {
				if (contact.getId() == id) {
					return contact;
				}
			}
			throw new ContactNotFoundException();

		} else {
			throw new UserNotFoundException();
		}
	}

	public List<Contact> findAllContacts(String userName)
			throws UserNotFoundException {
		if (userName.equals(user.getUserName())) {
			return user.getContacts();
		} else {
			throw new UserNotFoundException();
		}
	}

	public Contact addNewContact(String userName, Contact contact)
			throws UserNotFoundException {
		if (userName.equals(user.getUserName())) {
			user.getContacts().add(contact);
			return contact;
		} else {
			throw new UserNotFoundException();
		}
	}

	public Contact updateContact(String userName, Contact contact)
			throws UserNotFoundException, ContactNotFoundException {

		if (userName.equals(user.getUserName())) {
			for (Contact c : user.getContacts()) {
				if (c.getId() == contact.getId()) {
					user.getContacts().remove(c);
					user.getContacts().add(contact);
					return contact;
				}
			}
			throw new ContactNotFoundException();

		} else {
			throw new UserNotFoundException();
		}
	}

	public Contact removeContact(String userName, Integer id)
			throws UserNotFoundException, ContactNotFoundException {

		if (userName.equals(user.getUserName())) {
			for (Contact c : user.getContacts()) {
				if (c.getId() == id) {
					user.getContacts().remove(c);
					return c;
				}
			}
			throw new ContactNotFoundException();

		} else {
			throw new UserNotFoundException();
		}
	}

}
