package com.app.model;

import java.util.ArrayList;
import java.util.List;

public class User {

	private String userName;
	private List<Contact> contacts=new ArrayList<Contact>();

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<Contact> getContacts() {
		return contacts;
	}

	public void setContacts(List<Contact> contacts) {
		this.contacts = contacts;
	}

}
