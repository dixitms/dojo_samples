package com.bank.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.bank.model.Account;
import com.bank.service.AccountService;

@Controller
@RequestMapping("/accounts")
public class AccountController {

	@Autowired
	private AccountService accountService;

	@RequestMapping
	public ModelAndView viewAllAccounts() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("accounts", accountService.getAllAccounts());
		mav.setViewName("accounts");
		return mav;
	}

	// ---------------------------------------------------

	// AJAX Request
	@RequestMapping(params = { "num" }, produces = { "application/json" })
	public @ResponseBody Account viewAccount(@RequestParam String num,
			@ModelAttribute String attr) {
		return accountService.getAccount(num);
	}

	// ----------------------------------------------------

	@RequestMapping("/a")
	public void a() {

	}

	@RequestMapping("/b")
	public void b() {

	}

	@ModelAttribute
	public void load(Model model) {
		// create / find model
		model.addAttribute("some", "");
	}

}
