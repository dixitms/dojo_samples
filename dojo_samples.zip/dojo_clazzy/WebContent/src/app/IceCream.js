/**
 * 
 */

define([ 'dojo/_base/declare' ], function(declare) {

	var VannilaSoftServ = declare(null, {
		constructor : function() {
			console.log('adding soft serv..');
		}

	});

	var OreoMixin = declare(null, {
		kind : 'plain',
		constructor : function() {
			console.log('mixing in oreos');
		}
	});

	var CookieDoughMixin = declare(null, {
		chunkSize : 'medium',
		constructor : function() {
			console.log('mixing in cookie dough');
		}
	});

	var IceCream = declare([ VannilaSoftServ, OreoMixin, CookieDoughMixin ], {
		constructor : function() {
			console.log('A IceCream with ' + this.kind + ' oreos and '
					+ this.chunkSize + '- sized chunks of cookie dough');
		}
	});

	// var iceCream = new IceCream();
	// console.log(iceCream instanceof IceCream);
	// console.log(iceCream instanceof VannilaSoftServ);
	// console.log(iceCream instanceof OreoMixin);

	return IceCream;

});
