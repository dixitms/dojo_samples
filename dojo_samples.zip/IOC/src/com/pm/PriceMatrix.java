package com.pm;

public interface PriceMatrix {

	public abstract double getprice(String item);

}