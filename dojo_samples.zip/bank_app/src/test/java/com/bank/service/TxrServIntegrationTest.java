package com.bank.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@ContextConfiguration({ "classpath:application_layer.xml","classpath:infra_Layer.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class TxrServIntegrationTest {

	@Autowired
	private TransferService transferService;

	@Test
	@Transactional
	public void txrTest() {

		String from = "1";
		String to = "2";

		double amount = 100.00;

		transferService.tranfser(amount, from, to);

		Assert.assertTrue(true);

	}
	

	
	

}
