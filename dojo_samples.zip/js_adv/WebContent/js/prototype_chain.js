/**
 *  prototype-chain/inheritance
 */

 var a=Object.create(Object.prototype);
 a.x=5;
 a.y=6;
 
 var b=Object.create(a);
 b.z=10;
 b.x=12;
 
 var c=Object.create(b);
 c.y=200;
 
//-------------------------------------

console.log(a.x);
console.log(a.y);
console.log(a.z);


console.log(b.x);
console.log(b.y);
console.log(b.z);


console.log(c.x);
console.log(c.y);
console.log(c.z);

