/**
 * 
 */

function training() {

	var trainer = 'naga';

	console.log(trainer + " teaching JS");

	return function() {
		console.log('by ' + trainer + ' , learnt JS');
	}

}



var jsStudent = training();

jsStudent();
