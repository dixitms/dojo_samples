package com.mycompnay.hr.ws;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import com.mycompnay.hr.schemas.HolidayRequest;
import com.mycompnay.hr.schemas.HolidayResponse;

@WebService(name = "HumanResource",
			portName = "HumanResourcePort",
			serviceName = "HumanResourceService",
			targetNamespace = "http://mycompany.com/hr/definitions",
			wsdlLocation = "WEB-INF/wsdl/HolidayRequest.wsdl")
public class HolidayServiceEndpoint {

	@WebMethod(operationName = "Holiday")
	public HolidayResponse holidayRequest(
			@WebParam(partName = "HolidayRequest", targetNamespace = "http://mycompany.com/hr/schemas") HolidayRequest holidayRequest) {

		System.out.println("Received HolidayRequest");

		HolidayResponse response = new HolidayResponse();
		response.setStatus("Enjoy Your Holiday");

		return response;
	}

}
