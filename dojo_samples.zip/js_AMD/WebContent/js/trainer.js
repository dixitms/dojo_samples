/**
 * 
 */

define('js/trainer', [], function() {

	var name = 'Naga';

	return {
		doTeach : function() {
			console.log(name + ": Teaching JS");
		}
	}

});