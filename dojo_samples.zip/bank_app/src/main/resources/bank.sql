
create SCHEMA dell;

create table dell.ACCOUNTS(
no varchar(10) primary key,
name varchar(50),
balance double,
status varchar(10),
CHECK (balance>=0)
);



insert into  dell.ACCOUNTS values('1','A',1000.00,'ACTIVE');
insert into  dell.ACCOUNTS values('2','B',-10.00,'ACTIVE');

//----------------------------------------------------------------------------------------------------------------

DELIMITER $$
CREATE PROCEDURE raise_application_error(IN CODE INTEGER, IN MESSAGE VARCHAR(255)) SQL SECURITY INVOKER DETERMINISTIC
BEGIN
  CREATE TEMPORARY TABLE IF NOT EXISTS RAISE_ERROR(F1 INT NOT NULL);

  SELECT CODE, MESSAGE INTO @error_code, @error_message;
  INSERT INTO RAISE_ERROR VALUES(NULL);
END;
$$

//------------------------------------------------------------------------------------------------------------------


CREATE TRIGGER accounts_balance BEFORE UPDATE ON accounts FOR EACH ROW
BEGIN 
  IF NEW.balance < 0 THEN
    CALL raise_application_error(3001, 'Insufficient Fund!');
  END IF;
END
$$

//-------------------------------------------------------------------------------------------------------------------