package com.bank.repo;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bank.model.Account;
import com.bank.service.TransferService;
import com.spring.AccRepoQualifier;

@Repository
@AccRepoQualifier(tech = "HIBERNATE")
public class HibAccountRepository implements AccountRepository {

	@Autowired
	private SessionFactory sessionFactory;

	public HibAccountRepository() {
		System.out.println("HibAccRep bean created...");
	}

	public Account load(String num) {
		return (Account) sessionFactory.getCurrentSession().get(Account.class,num);
	}

	public void update(Account account) {
		sessionFactory.getCurrentSession().update(account);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Account> findAll() {
		return sessionFactory.getCurrentSession().createQuery("from Account")
				.list();
	}

}
