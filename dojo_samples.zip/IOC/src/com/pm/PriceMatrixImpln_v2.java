package com.pm;

public class PriceMatrixImpln_v2 implements PriceMatrix {

	public double getprice(String item) {
		// code..
		return 100.00;
	}

}
