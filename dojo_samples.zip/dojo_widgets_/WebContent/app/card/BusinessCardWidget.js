define([ 'dojo/_base/declare', "dijit/_WidgetBase", "dijit/_TemplatedMixin",
		"dojo/text!./templates/BusinessCard.html" ],

function(declare, _WidgetBase, _TemplatedMixin, template) {

	declare("app/card/BusinessCardWidget", [ _WidgetBase, _TemplatedMixin ], {

		templateString : template,

		// Attributes
		name : "unknown",
		_setNameAttr : {
			node : "nameNode",
			type : "innerHTML"
		},

		nameClass : "employeeName",
		_setNameClassAttr : {
			node : "nameNode",
			type : "class"
		},

		phone : "unknown",
		_setPhoneAttr : {
			node : "phoneNode",
			type : "innerHTML"
		}
		
	// _setPhoneAttr:function(ph){
	// this._set('phone',ph);
	// }

	});

});